package com.capg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capg.beans.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	
    @Query ("from Employee where salary=?1 order by ename")
	List<Employee> findBySalary (double salary);
	
    
	@Query("from Employee where salary between 400 and 4000")
	List<Employee> findByRange();
	
	
	
}
