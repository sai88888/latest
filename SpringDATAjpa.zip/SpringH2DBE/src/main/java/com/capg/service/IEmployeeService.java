package com.capg.service;

public interface IEmployeeService {

	public String getEmployeeById() {
		
	}
	
	
}
