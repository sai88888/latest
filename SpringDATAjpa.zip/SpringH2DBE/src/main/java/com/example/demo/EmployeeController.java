package com.example.demo;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;



@Controller
public class EmployeeController {
	@Autowired
	DAORepository repo;
	
	@RequestMapping("/")
	public String form() {
		return "file";
	}
	
	@PostMapping("/display")
	
	public String display(Employee emp,Model model) {
		
		model.addAttribute("emp",emp);
		repo.save(emp);
		
		return "display";
	}
	@GetMapping("/getemployee")
	@ResponseBody
	public String getEmployee (int eid) {
		
	Employee e =	repo.findById(eid).orElse(new Employee());
		return e.toString();
	}
	@GetMapping("/getAll")
	@ResponseBody
	public String getAll() {
		
		ArrayList<Employee> list = new ArrayList<Employee>();
		Iterable<Employee> it = repo.findAll();
		Iterator<Employee> itr = it.iterator();
		while(itr.hasNext()) {
			Employee employee = (Employee) itr.next();
			list.add(employee);
		}
		return list.toString();
	}
}
