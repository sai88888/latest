package com.capg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication//instead of configurable
public class SpringBootApp1Application {

	public static void main(String[] args) {
	ConfigurableApplicationContext context=	SpringApplication.run(SpringBootApp1Application.class, args);
	
	
	Employee emp=context.getBean(Employee.class);
	
	
	emp.setEid(102);
	emp.setEname("sai");
	emp.setEsalary(70000);
	System.out.println(emp);
	
	}

}
