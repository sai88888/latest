package snippet;

public class Snippet {
	ConfigurableApplicationContext context=	SpringApplication.run(SpringBootApp1Application.class, args);
		
		
		Employee emp=context.getBean(Employee.class);
		
		
		emp.setEid(102);
		emp.setEname("sai");
		emp.setEsalary(70000);
		System.out.println(emp);
}

