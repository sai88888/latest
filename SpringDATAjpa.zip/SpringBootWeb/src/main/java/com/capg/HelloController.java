package com.capg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {
	/*@Autowired
	Employee e;
*/
	@RequestMapping("/")
	public String form() {
		return "File";
	}

	@RequestMapping("/display")
	// public String display(HttpServletRequest request,HttpServletResponse
	// response,HttpSession session) {

	//public String display(@RequestParam("eid") int eid, @RequestParam("ename") String ename,
			//@RequestParam("esalary") int esalary, Model m) {
	
	            @PostMapping("/display")
				public ModelAndView display(Employee emp) {

		// int eid= Integer.parseInt(request.getParameter("eid"));
		// String ename= request.getParameter("ename");
		// int salary = Integer.parseInt(request.getParameter("esalary"));

		ModelAndView mv =new ModelAndView();
		mv.addObject("emp",emp);
		mv.setViewName("display");

		return mv;
	}

}
