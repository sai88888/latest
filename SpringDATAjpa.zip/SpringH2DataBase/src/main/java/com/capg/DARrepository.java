package com.capg;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DARrepository extends CrudRepository<Employee,Integer> {

	
	
	
	
	
	
}
