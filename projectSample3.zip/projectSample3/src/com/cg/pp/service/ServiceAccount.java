package com.cg.pp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.cg.pp.bean.AccountDetails;
import com.cg.pp.bean.TransactionDetails;
import com.cg.pp.dao.DataAccount;

public class ServiceAccount {
	DataAccount data = new DataAccount();
	Random rand = new Random();

	public void createAccount(AccountDetails account) {
		TransactionDetails transaction = new TransactionDetails();
		data.setAccountList(account);
		transaction.setAccountNumber(account.getAccountNumber());
		transaction.setCredit(account.getAmount());
		transaction.setDebit(0);
		transaction.setAmount(account.getAmount());
		data.setTransactionList(transaction);
	}

	public double showBalance(int accountNumber) {
		List<AccountDetails> accountList = data.getAccountList();

		for (AccountDetails accountDetail : accountList) {

			if (accountNumber == accountDetail.getAccountNumber()) {
				return accountDetail.getAmount();
			}
		}
		return 0;

	}

	public double deposit(int accountNumber, double credit) {
		List<AccountDetails> accountList = data.getAccountList();

		for (AccountDetails accountDetail : accountList) {

			if (accountNumber == accountDetail.getAccountNumber()) {
				TransactionDetails transaction = new TransactionDetails();
				double balance = accountDetail.getAmount();

				accountDetail.setAmount(balance + credit);
				transaction.setAccountNumber(accountDetail.getAccountNumber());
				transaction.setCredit(credit);
				transaction.setDebit(0);
				transaction.setAmount(accountDetail.getAmount());
				data.setTransactionList(transaction);
				return accountDetail.getAmount();
			}
		}

		return 0;

	}

	public double withdraw(int accountNumber, double debit) {
		List<AccountDetails> accountList = data.getAccountList();

		for (AccountDetails accountDetail : accountList) {

			if (accountNumber == accountDetail.getAccountNumber()) {
				TransactionDetails transaction = new TransactionDetails();
				double balance = accountDetail.getAmount();
				if (balance < debit) {
					return -1;
				}
				accountDetail.setAmount(balance - debit);
				transaction.setAccountNumber(accountDetail.getAccountNumber());
				transaction.setCredit(0);
				transaction.setDebit(debit);
				transaction.setAmount(accountDetail.getAmount());
				data.setTransactionList(transaction);
				return accountDetail.getAmount();
			}
		}
		return 0;
	}

	public double fundTransfer(int senderAccountNumber, int recieverAccountNumber, double transferAmount) {
		double returnAmount = withdraw(senderAccountNumber, transferAmount);
		deposit(recieverAccountNumber, transferAmount);
		return returnAmount;
	}

	public List<TransactionDetails> getTransactionDetails(int accountNumber) {
		List<TransactionDetails> transactionList = data.getTransactionList();
		List<TransactionDetails> transactionList2 = new ArrayList<>();
		for (TransactionDetails transactionDetail : transactionList) {
			if (accountNumber == transactionDetail.getAccountNumber()) {
				transactionList2.add(transactionDetail);
			}
		}
		return transactionList2;
	}

	public boolean validateAccountNumber(int accountNumber) {
		List<AccountDetails> accountList = data.getAccountList();
		for (AccountDetails accountDetail : accountList) {
			if (accountNumber == accountDetail.getAccountNumber())
				return true;
		}
		return false;
	}

}
