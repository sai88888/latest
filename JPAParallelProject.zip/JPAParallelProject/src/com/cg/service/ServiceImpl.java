package com.cg.service;

import com.cg.dao.DaoImpl;
import com.cg.entities.Account;
import com.cg.entities.Customer;

public class ServiceImpl implements Service {
	
	DaoImpl dao = new DaoImpl();
	
	public void createCustomerService(Customer customer) {
		dao.beginTransaction();
		dao.createCustomerDao(customer);
		dao.commitTransaction();
	}
	
	public Account showBalanceService(int accountNo) {
		dao.beginTransaction();
		Account account = dao.getAccount(accountNo);
		dao.commitTransaction();
		return account;
	}
	
	public void depositService(int depositAccount, double depositAmount) {
		dao.beginTransaction();
		Account account = dao.getAccount(depositAccount);
		account.setBalance(account.getBalance() + depositAmount);
		dao.commitTransaction();
	}
	
	public void withdrawService(int withdrawAccount, double withdrawAmount) {
		dao.beginTransaction();
		Account account = dao.getAccount(withdrawAccount);
		account.setBalance(account.getBalance() - withdrawAmount);
		dao.commitTransaction();
	}
	
	public void fundTransferService(int senderAccountNo, int receiverAccountNo, double transferAmount) {
		dao.beginTransaction();
		Account senderAccount = dao.getAccount(senderAccountNo);
		Account receiverAccount = dao.getAccount(receiverAccountNo);
		senderAccount.setBalance(senderAccount.getBalance() - transferAmount);
		receiverAccount.setBalance(receiverAccount.getBalance() + transferAmount);
		dao.commitTransaction();
	}

}
