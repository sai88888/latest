
package jdbcProjectPackage;
import java.sql.*;
public class OracleCon {
        public static void main(String[]args) {
            try {
                //step1 load the driver class for oracle
                Class.forName("oracle.jdbc.driver.OracleDriver");
               
                //step2 create the connection object
                Connection con=DriverManager.getConnection(
                        "jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg513","training513");
               
                //step3 create the statement object
                Statement stmt=con.createStatement();
               
                //preparedStatement pstm=con.prepareStatement("");
                //CallableStatement cstm=con.prepareCall("");
                con.close();
            }catch(Exception e) {System.out.println(e);}
        }
}
