package jdbcProjectPackage;

import java.util.Scanner;
	import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
	public class PreparedStatementUpdateDemo {
	  public static void main (String args[]) {
		  Connection con;
		  PreparedStatement pst;
		  Scanner scanner =new Scanner (System.in);
		  String uName = scanner.next();
		  int uId = scanner.nextInt();
		  
		  try {
			  Class.forName("oracle.jdbc.driver.OracleDriver");
			  con = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg513","training513");
			  pst = con.prepareStatement("update customers3 set customer_name=? where customer_id =?");
			  pst.setString(1,uName);
			  pst.setInt(2,uId);
			  pst.executeUpdate();
			  System.out.println("row updated");
		  }catch(Exception e) {
			  System.out.println(e);
		  }
		  scanner.close();
	  }
	}

