package jdbcProjectPackage;
import java.sql.*;
public class UpdatableAndScrollable {
public static void main (String args[]) {	  
		  
		  try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg513","training513");
			Statement statement = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet results = statement.executeQuery("SELECT customer_id,customer_name from customers3");
			int concurrency = results.getConcurrency();
			System.out.println(concurrency);
			System.out.println(ResultSet.CONCUR_UPDATABLE);
			if(concurrency == ResultSet.CONCUR_UPDATABLE)
			{
			results.absolute(2);
			results.updateString(2,"eee");
			results.updateRow();
			}
			else {
				System.out.println("rr");
			}
			
		  }
		  catch(Exception e) {
			  System.out.println(e);
		  }
}
}