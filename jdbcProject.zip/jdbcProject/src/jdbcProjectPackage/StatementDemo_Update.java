package jdbcProjectPackage;
import java.sql.*;
public class StatementDemo_Update {
  public static void main (String args[]) {
	  Connection con;
	  Statement st;
	  try {
		  Class.forName("oracle.jdbc.driver.OracleDriver");
		  con = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg513","training513");
		  st = con.createStatement();
		  st.execute("update customers3 set customer_name where customer_id=1");
		  System.out.println("row updated");
	  }catch(Exception e) {
		  System.out.println(e);
	  }
  }
}
