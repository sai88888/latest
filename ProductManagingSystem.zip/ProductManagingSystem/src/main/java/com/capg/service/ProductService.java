package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.productbean.Product;
import com.capg.repository.ProductRepository;

@Service
public class ProductService implements IProductService {
	@Autowired
	ProductRepository repo;

	@Override
	public List<Product> FetchProductList() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Product addProduct(Product pnd) {
		// TODO Auto-generated method stub
		return repo.save(pnd);
	}

	@Override
	public Product updateProduct(Product pnd) {
		// TODO Auto-generated method stub
		return repo.save(pnd);
	}

	@Override
	public void deleteProductById(int pid) {
		// TODO Auto-generated method stub
		repo.deleteById(pid);
	}

}
