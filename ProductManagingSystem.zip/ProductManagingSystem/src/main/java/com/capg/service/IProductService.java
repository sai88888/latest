package com.capg.service;

import java.util.List;


import com.capg.productbean.Product;

public interface IProductService {

	public List<Product> FetchProductList();
	
	public Product addProduct(Product pnd);
	
	public Product updateProduct(Product pnd);
	
	public void deleteProductById(int pid);
}
