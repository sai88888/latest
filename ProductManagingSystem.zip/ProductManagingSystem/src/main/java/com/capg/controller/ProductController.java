package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.capg.productbean.Product;
import com.capg.service.IProductService;

@RestController
public class ProductController {
	
	@Autowired
	IProductService service;

@GetMapping(path="/products/all",produces="application/json")
public List<Product> FetchProductList() {
	return service.FetchProductList();
}

@PostMapping(path="/products/product",consumes="application/json")
public Product addEmployee(@RequestBody Product pdt) {
	return service.addProduct(pdt);
}

@PutMapping(path="/products/product",consumes="application/json")
public Product updateProduct(@RequestBody Product pdt) {
	return service.updateProduct(pdt);
}

@DeleteMapping("/products/product/{pid}")
public void deleteProductById(@PathVariable int pid) {
	service.deleteProductById(pid);
}

}
