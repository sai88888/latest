package com.capg.productbean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;

@Component
@Entity
public class Product {
	
	//@NotNull
	@Id
 private int pid;
@NotNull
 private String pname;
	//@Max(value = 90000)
 private double price;
 private String MNM;
public int getPid() {
	return pid;
}
public void setPid(int pid) {
	this.pid = pid;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public String getMNM() {
	return MNM;
}
public void setMNM(String mNM) {
	MNM = mNM;
}
 
}
