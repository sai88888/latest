package com.capg.globalexception;

public class ExceptionPdt extends Exception{

}
