package com.capg.globalexception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;


import com.capg.productbean.ExceptionBean;




@ControllerAdvice
public class GlobalException {

	
	
	@ResponseBody
	@ResponseStatus(value=HttpStatus.NOT_FOUND)
	@ExceptionHandler(value={Exception.class})
	public ExceptionBean errorHandler(Exception e,HttpServletRequest req) {
		String httpreq = e.getMessage();
		String uri = req.getRequestURL().toString();
		return new ExceptionBean(uri, httpreq);
}
}