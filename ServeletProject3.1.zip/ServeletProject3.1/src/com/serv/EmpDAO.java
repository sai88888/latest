package com.serv;
import java.sql.*;

import beans.Employee;


public class EmpDAO {
	
	public int addEmployee(Employee emp) {
		int n = 0;
		try {
			Connection conn = DBUtil.getConn();
			String query = "insert into employee values(?,?,?)";
			PreparedStatement pstmt = conn.prepareStatement(query);
			
			pstmt.setInt(1, emp.getEid());
			pstmt.setString(2, emp.getEname());
			pstmt.setDouble(3, emp.getSalary());
			
			n = pstmt.executeUpdate();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return n;
	}
}
